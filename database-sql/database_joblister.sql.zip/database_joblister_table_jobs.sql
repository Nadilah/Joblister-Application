
-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `company` varchar(255) NOT NULL,
  `job_title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `salary` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `contact_user` varchar(255) NOT NULL,
  `contact_email` varchar(255) NOT NULL,
  `post_date` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `category_id`, `company`, `job_title`, `description`, `salary`, `location`, `contact_user`, `contact_email`, `post_date`) VALUES
(1, 1, 'JP Mortage', 'Senior Investor', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut ex nisi, pretium in elit ac, bibendum porttitor ligula. Quisque interdum leo quis posuere porta. Nunc eu scelerisque arcu. Cras id ante eu ante viverra pellentesque ut at dolor.', '90k', 'Boston', 'Brad Traversy', 'brad@gmail.com', '2020-09-20 09:49:49'),
(2, 2, 'Tech Guy', 'Entry Level Programmer', 'Nullam bibendum turpis efficitur arcu hendrerit commodo. Proin pharetra mi auctor aliquam luctus. ', '50k', 'Springfield', 'Johb Doe', 'john@gmail.com', '2020-09-20 09:49:49');
